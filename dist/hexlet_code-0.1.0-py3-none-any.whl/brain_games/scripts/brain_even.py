#!/usr/bin/env python3
from ..game import game


def main():  
    game("even")


if __name__ == "__main__":
    main()
