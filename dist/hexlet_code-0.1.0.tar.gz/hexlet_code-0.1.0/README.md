### Hexlet tests and linter status:
[![Actions Status](https://github.com/VScheg/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/VScheg/python-project-49/actions)
### CodeClimate Badge
<a href="https://codeclimate.com/github/VScheg/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/80c648e273b19cf6491c/maintainability" /></a>
