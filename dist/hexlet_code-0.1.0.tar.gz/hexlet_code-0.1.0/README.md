### Hexlet tests and linter status:
[![Actions Status](https://github.com/VScheg/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/VScheg/python-project-49/actions)
### CodeClimate Badge
<a href="https://codeclimate.com/github/VScheg/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/80c648e273b19cf6491c/maintainability" /></a>
### brain-even
<a href="https://asciinema.org/a/Wym53gHrto8PgnTUcAv041wqQ" target="_blank"><img src="https://asciinema.org/a/Wym53gHrto8PgnTUcAv041wqQ.svg" /></a>
### brain-calc
<a href="https://asciinema.org/a/nj8zoHFDUWpOpPP3ST0u3vWuR" target="_blank"><img src="https://asciinema.org/a/nj8zoHFDUWpOpPP3ST0u3vWuR.svg" /></a>
### brain-gcd
<a href="https://asciinema.org/a/8fbwhDpslbuiwadSs0l4UL7Ww" target="_blank"><img src="https://asciinema.org/a/8fbwhDpslbuiwadSs0l4UL7Ww.svg" /></a>