#!/usr/bin/env python3
from ..game import game


def main():
    task = "What number is missing in the progression?"
    game("progression", task)


if __name__ == "__main__":
    main()
