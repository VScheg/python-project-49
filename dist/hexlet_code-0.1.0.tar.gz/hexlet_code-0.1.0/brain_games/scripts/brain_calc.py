#!/usr/bin/env python3
from ..game import game


def main(): 
    game("calc")


if __name__ == "__main__":
    main()
